package FinalProject;

import java.io.BufferedWriter;
import java.io.FileWriter;

class LinkedListBank {
    Account head = null;

    void insert(int accNo, String name, double balance) {
        Account newAcc = new Account(accNo, name, balance);

        if (head == null) {
            head = newAcc;
        } else {
            Account temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newAcc;
        }

        saveToFile(); // save after insert
        System.out.println("Account Created");
    }

    void display() {
        Account temp = head;
        while (temp != null) {
            temp.display();
            temp = temp.next;
        }
    }

   
    void saveToFile() {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("accounts.txt"));

            Account temp = head;
            while (temp != null) {
                bw.write(temp.accNo + "," + temp.name + "," + temp.balance);
                bw.newLine();
                temp = temp.next;
            }

            bw.close();
        } catch (Exception e) {}
    }
}