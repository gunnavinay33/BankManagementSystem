package FinalProject;

class StackDS {
    String stack[] = new String[10];
    int top = -1;

    void push(String data) {
        if (top < 9) {
            stack[++top] = data;
        }
    }

    void popAll() {
        while (top != -1) {
            System.out.println(stack[top--]);
        }
    }
}