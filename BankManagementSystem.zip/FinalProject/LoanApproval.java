package FinalProject;

class LoanApproval {

    static boolean isLoanApproved(boolean tax, boolean job, double salary, int cibil) 
    {

        return (tax && job && salary >= 25000 && cibil >= 700);
    }
}