package FinalProject;

import java.io.BufferedReader;
import java.io.FileReader;

class FileLoader {

    void load(LinkedListBank bank) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("accounts.txt"));

            String line;

            while ((line = br.readLine()) != null) {
                String parts[] = line.split(",");

                int accNo = Integer.parseInt(parts[0]);
                String name = parts[1];
                double balance = Double.parseDouble(parts[2]);

                bank.insert(accNo, name, balance);
            }

            br.close();
        } catch (Exception e) {}
    }
}