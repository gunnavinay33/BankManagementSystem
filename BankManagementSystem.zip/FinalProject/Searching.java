package FinalProject;

class Searching {
    void search(Account head, int key) {
        Account temp = head;

        while (temp != null) {
            if (temp.accNo == key) {
                temp.display();
                return;
            }
            temp = temp.next;
        }
        System.out.println("Account Not Found");
    }
}