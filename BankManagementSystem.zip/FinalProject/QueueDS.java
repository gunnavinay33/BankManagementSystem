package FinalProject;

class QueueDS {
    String queue[] = new String[10];
    int front = 0, rear = -1;

    void enqueue(String name) {
        if (rear < 9) {
            queue[++rear] = name;
        }
    }

    void dequeue() {
        if (front <= rear) {
            System.out.println("Serving: " + queue[front++]);
        }
    }
}