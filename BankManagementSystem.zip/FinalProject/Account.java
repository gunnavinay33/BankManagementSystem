package FinalProject;

class Account {
    int accNo;
    String name;
    double balance;
    Account next;

    Account(int accNo, String name, double balance) {
        this.accNo = accNo;
        this.name = name;
        this.balance = balance;
        this.next = null;
    }

    void display() {
        System.out.println(accNo + " " + name + " " + balance);
    }
}