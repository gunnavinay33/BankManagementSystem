package FinalProject;

class PriorityQueueDS {
    void showHighest(Account head) {
        if (head == null) return;

        Account max = head;
        Account temp = head;

        while (temp != null) {
            if (temp.balance > max.balance) {
                max = temp;
            }
            temp = temp.next;
        }

        System.out.println("Highest Balance Customer:");
        max.display();
    }
}