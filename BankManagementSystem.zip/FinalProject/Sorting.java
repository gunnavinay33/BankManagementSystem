package FinalProject;

class Sorting {
    void sort(Account head) {
        for (Account i = head; i != null; i = i.next) {
            for (Account j = i.next; j != null; j = j.next) {
                if (i.balance > j.balance) {

                    int tAcc = i.accNo;
                    String tName = i.name;
                    double tBal = i.balance;

                    i.accNo = j.accNo;
                    i.name = j.name;
                    i.balance = j.balance;

                    j.accNo = tAcc;
                    j.name = tName;
                    j.balance = tBal;
                }
            }
        }
        System.out.println("Sorted");
    }
}