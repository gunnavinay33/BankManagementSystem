package FinalProject;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        LinkedListBank bank = new LinkedListBank();
        FileLoader loader = new FileLoader();
        loader.load(bank); // load file data

        Searching search = new Searching();
        Sorting sort = new Sorting();
        StackDS stack = new StackDS();
        QueueDS queue = new QueueDS();
        PriorityQueueDS pq = new PriorityQueueDS();

        while (true) {
            System.out.println("\n1.Create\n2.Display\n3.Search\n4.Sort\n5.Stack\n6.Queue\n7.Priority\n8.Loan\n9.Exit");
            int ch = sc.nextInt();

            switch (ch) {

                case 1:
                    System.out.println("Enter accNo name balance");
                    bank.insert(sc.nextInt(), sc.next(), sc.nextDouble());
                    break;

                case 2:
                    bank.display();
                    break;

                case 3:
                    System.out.println("Enter accNo");
                    search.search(bank.head, sc.nextInt());
                    break;

                case 4:
                    sort.sort(bank.head);
                    break;

                case 5:
                    stack.push("Transaction");
                    stack.popAll();
                    break;

                case 6:
                    queue.enqueue("Customer");
                    queue.dequeue();
                    break;

                case 7:
                    pq.showHighest(bank.head);
                    break;

                case 8:
                    System.out.println("Tax(true/false):");
                    boolean tax = sc.nextBoolean();

                    System.out.println("Job(true/false):");
                    boolean job = sc.nextBoolean();

                    System.out.println("Salary:");
                    double sal = sc.nextDouble();

                    System.out.println("CIBIL:");
                    int cibil = sc.nextInt();

                    boolean res = LoanApproval.isLoanApproved(tax, job, sal, cibil);

                    System.out.println(res ? "Approved" : "Rejected");
                    break;

                case 9:
                    return;
            }
        }
    }
}